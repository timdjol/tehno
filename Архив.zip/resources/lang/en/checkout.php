<?php

return [
    'delivery' => 'Delivery methods',
    'courier' => 'Order via courier',
    'delivery_address' => 'Delivery address',
    'comment' => 'Comment for the courier',
    'pickup' => 'Pickup',
    'payment' => 'Payment Methods',
    'cash' => 'Cash',
    'card' => 'Bank card',
    'russia' => 'Russia',
    'other' => 'Other countries',
    'process' => 'In the process of acquiring...',
];