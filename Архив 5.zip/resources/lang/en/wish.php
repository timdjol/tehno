<?php

return [
    'add' => ' added to wishlist',
    'unavailable' => ' not available in wishlist',
    'deleted' => ' deleted from wishlist',
    'cleared' => 'Wishlist cleared',
    'title' => 'Wishlist',
    'action' => 'Action',
    'clear' => 'Clear Wishlist',
    'not' => 'Wishlist not found',
    'delete' => 'Delete'
];