<?php

return [
    'dear' => 'Уважаемый ',
    'order_sum' => '>Ваш заказ на сумму ',
    'order_create' => ' создан',
];