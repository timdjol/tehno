@extends('layouts.master')

@section('title', $skus->product->title)

@section('content')

    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/fotorama/4.6.4/fotorama.min.js" integrity="sha512-cWEytOR8S4v/Sd3G5P1Yb7NbYgF1YAUzlg1/XpDuouZVo3FEiMXbeWh4zewcYu/sXYQR5PgYLRbhf18X/0vpRg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fotorama/4.6.4/fotorama.min.css" integrity="sha512-bjwk1c6AQQOi6kaFhKNrqoCNLHpq8PT+I42jY/il3r5Ho/Wd+QUT6Pf3WGZa/BwSdRSIjVGBsPtPPo95gt/SLg==" crossorigin="anonymous" referrerpolicy="no-referrer" />


    <div class="main">
        <div class="container">
            <div class="catalog__address">
                <div class="catalog__address-path">
                    {{ $skus->product->category->title }}
                </div>
                <!-- <div class="catalog__address-price">Показать:</div> -->
            </div>

            <div class="product">
                <div class="product__card">
                    <div class="product__card-bluetitle-up">
                        {{ $skus->product->title }}
                    </div>
                    <div class="product-card">
                        <div class="fotorama" data-allowfullscreen="true" data-nav="thumbs" data-loop="true" data-autoplay="3000">
                            <img src="{{ Storage::url($skus->product->image) }}" alt="">
                            @foreach($images as $image)
                                <img loading=lazy src="{{ Storage::url($image->image) }}" alt="">
                            @endforeach

                        </div>
                        <div class="product-info">
                            <h2>
                                {{ $skus->product->title }}
                            </h2>
                            <p>
                                {{ $skus->product->short }}
                            </p>

                            <div class="product-info-price">
                                <p>Цена:</p>
                                <span> {{ $skus->price }} сом</span>
                            </div>


                            @if($skus->isAvailable() == 1)
                                <div class="stock in">В наличии</div>
                            @endif
                            @if($skus->isAvailable())
                                <form action="{{ route('basket-add', $skus) }}" method="post">
                                    <button class="more btn btn-primary" type="submit">Купить</button>
                                    @csrf
                                </form>
                            @else
                                <span>Недоступен</span><br>
                                <span>Подписаться</span>
                                @if($errors->get('email'))
                                    <div class="alert alert-warning">
                                        {!! $errors->get('email')[0] !!}
                                    </div>
                                @endif
                                <form action="{{ route('subscription', $skus) }}" method="post">
                                    <div class="form-group">
                                        <input type="text" name="email" placeholder="Email">
                                    </div>
                                    @csrf
                                    <button class="more">@lang('product.send')</button>
                                </form>
                            @endif
                        </div>
                    </div>

{{--                    <div class="product__card-props">--}}
{{--                        <div class="product__card-props-item">--}}
{{--                            <img src="./img/items/item_1.svg" alt="" />--}}
{{--                            <p>Lorem, ipsum dolor sit</p>--}}
{{--                        </div>--}}
{{--                        <div class="product__card-props-item">--}}
{{--                            <img src="./img/items/item_2.svg" alt="" />--}}
{{--                            <p>Lorem, ipsum dolor sit</p>--}}
{{--                        </div>--}}
{{--                        <div class="product__card-props-item">--}}
{{--                            <img src="./img/items/item_3.svg" alt="" />--}}
{{--                            <p>Lorem, ipsum dolor sit</p>--}}
{{--                        </div>--}}
{{--                        <div class="product__card-props-item">--}}
{{--                            <img src="./img/items/item_4.svg" alt="" />--}}
{{--                            <p>Lorem, ipsum dolor sit</p>--}}
{{--                        </div>--}}
{{--                    </div>--}}



                    <div class="product__card-description">
                        <div class="product__info">

                            <div class="product__text">
                                {!! $skus->product->descr1 !!}
                            </div>
                        </div>
                        <img src="{{ Storage::url($skus->product->imagedescr1) }}" alt="" />
                    </div>

                    <div class="product__card-description">
                        <img src="{{ Storage::url($skus->product->imagedescr2) }}" alt="" />
                        <div class="product__info">
                            <div class="product__text">
                                {!! $skus->product->descr2 !!}
                            </div>
                        </div>
                    </div>

                    <div class="product__card-description">
                        <div class="product__info">
                            <div class="product__text">
                                {!! $skus->product->descr3 !!}
                            </div>
                        </div>
                        <img src="{{ Storage::url($skus->product->imagedescr3) }}" alt="" />
                    </div>

                    <div class="product__card-description">
                        <img src="{{ Storage::url($skus->product->imagedescr4) }}" alt="" />
                        <div class="product__info">
                            <div class="product__text">
                                {!! $skus->product->descr4 !!}
                            </div>
                        </div>
                    </div>

                    <div class="product__card-description-one">
                        <div class="product__text-center">
                            {!! $skus->product->descr5 !!}
                        </div>
                        <img src="{{ Storage::url($skus->product->imagedescr5) }}" alt="" />
                        <!-- <div class="product__title-img">

                        </div> -->
                    </div>

                    <div class="product__card-bluetitle-bottom"></div>
                </div>
            </div>
        </div>
    </div>


    <style>

        .product__card-description-one img{
            margin: 10px 0;
        }
        .single .properties{
            margin: 20px 0;
        }

        .single .colors .color{
            display: inline-block;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            margin-right: 8px;
            position: relative;
            border: 1px solid #ddd;
        }
        .single .colors .color.current::after{
            content: "";
            position: absolute;
            width: 40px;
            height: 40px;
            left: -5px;
            top: -5px;
            border: 1px solid #ab8e83;
            border-radius: 50%;
        }
        .single .colors a{
            text-decoration: none;
        }
    </style>

@endsection

