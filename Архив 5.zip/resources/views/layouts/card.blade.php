<div class="catalog__card">
    <!-- каталог-блок-1 -->
    <div class="catalog__images">
        <img
                class="catalog__image catalog__active"
                src="{{ Storage::url($sku->product->image) }}"
        />
        <img
                class="catalog__image"
                src="{{ Storage::url($sku->product->imagecolor2) }}"
        />
        <!-- кнопка для модалки -->
{{--        <a class="catalog__openModalBtn" href="#!"--}}
{{--        >Быстрый просмотр</a--}}
{{--        >--}}

        <!-- модалка быстрого просмотра -->
        <div class="catalog__modal">
            <div class="catalog__modal-content">
                                        <span class="catalog__close"
                                        >&times;</span
                                        >
                <img
                        src="{{ Storage::url($sku->product->image) }}"
                        alt="Изображение 1"
                />
                <p>Текст для изображения 1</p>
                <img
                        src="image2.jpg"
                        alt="Изображение 2"
                />
                <p>Текст для изображения 2</p>
                <img
                        src="image3.jpg"
                        alt="Изображение 3"
                />
                <p>Текст для изображения 3</p>
            </div>
        </div>
    </div>

    <!-- каталог-блок-2 -->
    <div class="catalog__card-text">
        <div class="catalog__card-text-title">
            {{ $sku->product->title }}
        </div>

        <div class="catalog__card-text-color">
            <p>Цвет:</p>
            <div class="catalog__icons">
                <div class="catalog__icon white" style="background-color: {{ $sku->product->color }}"></div>
                <div class="catalog__icon grey" style="background-color: {{ $sku->product->color2 }}"></div>
            </div>
        </div>
        <div class="catalog__card-text-numbers">
            {{ $sku->price }} сом
        </div>
        <div class="catalog__card-text-text">
            {{ $sku->product->short }}
        </div>
    </div>

    <!-- каталог-блок-3 -->
    <div class="catalog__card-description">
        {!! $sku->product->charac !!}

        <a
                class="catalog__card-description-btn"
                href="{{ route('sku', [$sku->product->category->code, $sku->product->code, $sku]) }}"
        >Узнать больше</a
        >
    </div>
</div>
