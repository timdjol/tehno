@extends('layouts.master')

@section('title', 'Корзина')

@section('content')

    @if(session()->has('success'))
        <p class="alert alert-success">{{ session()->get('success') }}</p>
    @endif
    @if(session()->has('warning'))
        <p class="alert alert-warning">{{ session()->get('warning') }}</p>
    @endif

    <div class="main">
        <div class="container">
            <div class="catalog__address">
                <div class="catalog__address-path">Корзина</div>
                <!-- <div class="catalog__address-price">Показать:</div> -->
            </div>
            <div class="shoppingcart">
                <div class="shoppingcart__cards">
                    <!-- карточка товара -->
                    @foreach($order->skus as $sku)
                        <div class="shoppingcart__card">
                            <div class="shoppingcart__card-photo">
                                <img
                                        src="{{ Storage::url($sku->product->image) }}"
                                        alt=""
                                />
                            </div>
                            <div class="shoppingcart__descp">
                                <p>
                                    <b
                                    >{{ $sku->product->title }}</b
                                    >
                                </p>

                                <p>{{ $sku->product->short }}</p>
                            </div>

                            <div class="shoppingcart__card-price">
                                <div class="shoppingcart__card-price-num">
                                    <span>{{ $sku->price }} сом</span>
                                    <div class="counter-wrap">
                                        <form action="{{ route('basket-remove', $sku) }}" method="post">
                                            <button type="submit" class="btn btn-danger">-</button>
                                            @csrf
                                        </form>
                                        <span class="badge">{{ $sku->countInOrder }}</span>
                                        <form action="{{ route('basket-add', $sku) }}" method="post">
                                            <button type="submit" class="btn btn-success">+</button>
                                            @csrf
                                        </form>
                                    </div>
                                </div>

                                {{--                            <div class="shoppingcart__card-btn">Убрать</div>--}}
                            </div>
                        </div>
                    @endforeach


                </div>

                <div class="shoppingcart__order">
                    <div class="shoppingcart__order-block">
                        <div class="order-title">Итого:</div>
                        <div class="order-sum">{{ $order->getFullSum() }} сом</div>
                    </div>
                    <a href="{{ route('order') }}" class="more btn btn-success">Оформить заказ</a>
                </div>
            </div>
        </div>
    </div>

    <style>
        .shoppingcart__order .more {
            display: flex;
            margin: 0 auto;
            padding: 20px 35px;
            background-color: var(--color-orange);
            border-radius: 30px;
            border: none;
            cursor: pointer;
            transition: 0.2s ease;
        }
    </style>

@endsection
