<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\ProductRequest;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Image;
use App\Models\Product;
use App\Models\Property;
use App\Models\Sku;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Spatie\Backtrace\File;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $products = Product::paginate(40);
        return view('auth.products.index', compact('products'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //$categories = Category::get();
        //$categories = Category::where('parent_id', 0)->orderby('title', 'asc')->get();
        $categories = Category::select('title', 'id')->get();


        $brands = Brand::get();
        $properties = Property::get();
        return view('auth.products.form', compact('categories', 'properties', 'brands'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(ProductRequest $request, Product $product)
    {
        $request['code'] = Str::slug($request->title);
        $params = $request->all();
        unset($params['image']);
        if($request->has('image')){
            if($product->image != null) {
                Storage::delete($product->image);
            }
            $params['image'] = $request->file('image')->store('products');
        }
        unset($params['imagecolor1']);
        if($request->has('imagecolor1')){
            if($product->imagecolor1 != null) {
                Storage::delete($product->imagecolor1);
            }
            $path = $request->file('imagecolor1')->store('products');
            $params['imagecolor1'] = $path;
        }

        unset($params['imagecolor2']);
        if($request->has('imagecolor2')){
            if($product->imagecolor2 != null) {
                Storage::delete($product->imagecolor2);
            }
            $path = $request->file('imagecolor2')->store('products');
            $params['imagecolor2'] = $path;
        }

        unset($params['imagecolor3']);
        if($request->has('imagecolor3')){
            if($product->imagecolor3 != null) {
                Storage::delete($product->imagecolor3);
            }
            $path = $request->file('imagecolor3')->store('products');
            $params['imagecolor3'] = $path;
        }

        unset($params['imagedescr1']);
        if($request->has('imagedescr1')){
            if($product->imagedescr1 != null) {
                Storage::delete($product->imagedescr1);
            }
            $path = $request->file('imagedescr1')->store('products');
            $params['imagedescr1'] = $path;
        }

        unset($params['imagedescr2']);
        if($request->has('imagedescr2')){
            if($product->imagedescr2 != null) {
                Storage::delete($product->imagedescr2);
            }
            $path = $request->file('imagedescr2')->store('products');
            $params['imagedescr2'] = $path;
        }

        unset($params['imagedescr3']);
        if($request->has('imagedescr3')){
            if($product->imagedescr3 != null) {
                Storage::delete($product->imagedescr3);
            }
            $path = $request->file('imagedescr3')->store('products');
            $params['imagedescr3'] = $path;
        }

        unset($params['imagedescr4']);
        if($request->has('imagedescr4')){
            if($product->imagedescr4 != null) {
                Storage::delete($product->imagedescr4);
            }
            $path = $request->file('imagedescr4')->store('products');
            $params['imagedescr4'] = $path;
        }

        unset($params['imagedescr5']);
        if($request->has('imagedescr5')){
            if($product->imagedescr5 != null) {
                Storage::delete($product->imagedescr5);
            }
            $path = $request->file('imagedescr5')->store('products');
            $params['imagedescr5'] = $path;
        }

        //images
        //$product->properties()->sync($request->property_id);
        $prod = Product::create($params);

        $images = $request->file('images');
        if ($request->hasFile('images')) :
            foreach ($images as $image):
                $image = $image->store('products');
                DB::table('images')->insert(
                    array(
                        'image'=>  $image,
                        'product_id' => $prod->id,
                    )
                );
            endforeach;
        endif;

        session()->flash('success', 'Продукция ' . $request->title . ' добавлена');
        return redirect()->route('products.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(Product $product, Sku $skus)
    {
        $images = Image::where('product_id', $product->id)->get();
        return view('auth.products.show', compact('product', 'skus', 'images'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Product $product)
    {
        $categories = Category::where('parent_id', 0)->orderby('title', 'asc')->get();
        $brands = Brand::get();
        $properties = Property::get();
        $images = Image::where('product_id', $product->id)->get();
        return view('auth.products.form', compact('product', 'categories', 'properties', 'images', 'brands'));
    }

    /**
     * Update the specified resource in storage.
     * @param ProductRequest $request
     * @param Product $product
     * @return RedirectResponse
     */
    public function update(ProductRequest $request, Product $product)
    {
        $request['code'] = Str::slug($request->title);
        $params = $request->all();

        unset($params['image']);

        if($request->has('image')){
            if($product->image != null) {
                Storage::delete($product->image);
            }
            $path = $request->file('image')->store('products');
            $params['image'] = $path;
        }

        unset($params['imagecolor1']);
        if($request->has('imagecolor1')){
            if($product->imagecolor1 != null) {
                Storage::delete($product->imagecolor1);
            }
            $path = $request->file('imagecolor1')->store('products');
            $params['imagecolor1'] = $path;
        }

        unset($params['imagecolor2']);
        if($request->has('imagecolor2')){
            if($product->imagecolor2 != null) {
                Storage::delete($product->imagecolor2);
            }
            $path = $request->file('imagecolor2')->store('products');
            $params['imagecolor2'] = $path;
        }

        unset($params['imagecolor3']);
        if($request->has('imagecolor3')){
            if($product->imagecolor3 != null) {
                Storage::delete($product->imagecolor3);
            }
            $path = $request->file('imagecolor3')->store('products');
            $params['imagecolor3'] = $path;
        }

        unset($params['imagedescr1']);
        if($request->has('imagedescr1')){
            if($product->imagedescr1 != null) {
                Storage::delete($product->imagedescr1);
            }
            $path = $request->file('imagedescr1')->store('products');
            $params['imagedescr1'] = $path;
        }

        unset($params['imagedescr2']);
        if($request->has('imagedescr2')){
            if($product->imagedescr2 != null) {
                Storage::delete($product->imagedescr2);
            }
            $path = $request->file('imagedescr2')->store('products');
            $params['imagedescr2'] = $path;
        }

        unset($params['imagedescr3']);
        if($request->has('imagedescr3')){
            if($product->imagedescr3 != null) {
                Storage::delete($product->imagedescr3);
            }
            $path = $request->file('imagedescr3')->store('products');
            $params['imagedescr3'] = $path;
        }

        unset($params['imagedescr4']);
        if($request->has('imagedescr4')){
            if($product->imagedescr4 != null) {
                Storage::delete($product->imagedescr4);
            }
            $path = $request->file('imagedescr4')->store('products');
            $params['imagedescr4'] = $path;
        }

        unset($params['imagedescr5']);
        if($request->has('imagedescr5')){
            if($product->imagedescr5 != null) {
                Storage::delete($product->imagedescr5);
            }
            $path = $request->file('imagedescr5')->store('products');
            $params['imagedescr5'] = $path;
        }


        $product->properties()->sync($request->property_id);

        //unset($params['images']);
        $images = $request->file('images');


        if ($request->hasFile('images')) :
//            if($images != null) {
//                Storage::delete($images);
//                DB::table('images')->where('product_id', $product->id)->delete();
//            }
            foreach ($images as $image):
                $image = $image->store('products');
                //$arr[] = $image;

                DB::table('images')
                    ->where('product_id', $product->id)
                    ->updateOrInsert(['product_id' => $product->id, 'image' => $image]);
            endforeach;
        endif;
        $product->update($params);
        session()->flash('success', 'Продукция ' . $product->title . ' обновлена');
        return redirect()->route('products.index');
    }

    /**
     * Remove the specified resource from storage.
     * @param Product $product
     * @return RedirectResponse
     */
    public function destroy(Product $product, Sku $sku)
    {
        $product->delete();
        $sku->where('product_id', $product->id)->delete();
        session()->flash('success', 'Продукция ' . $product->title . ' удалена');
        return redirect()->route('products.index');
    }

    public function deleteImage($id)
    {
        $fullImgPath = storage_path("storage/products/$id.jpg");
        if(File::exists($fullImgPath)) {
            File::delete($fullImgPath);
        }
        $image = Image::destroy($id);


        return response()->json(['success' => 'User Deleted Successfully!']);
    }

}
